new Vue({
  el: '#app',
  data: {
    cards: [],
  filteredCards: [],
  isGridView: false,
  scrollLeft: 0,
  isUpdateIndicatorVisible: false,
  startX: 0,
  isDragging: false,
  searchQuery: '',
  selectedCategory: 'Todos',
  placeholderText: 'Busca pantalon, camiseta, sudadera...',
  favoriteButtonClicked: false,
  selectedCardIndex: -1,
  favorites: [],
  cart: [], // Agregar la propiedad del carrito
  isCartOpen: false,



  },
  mounted() {
    this.fetchData();
    this.filterByCategory('Todos'); // Llama al método para mostrar la categoría "Todos" al principio

  },
  methods: {
    async fetchData() {
      try {
        const response = await fetch('http://54.196.142.74/api/product');
        const data = await response.json();

        // Convert the object to an array
        this.cards = Object.values(data);

        // Initialize filteredCards with all data
        this.filteredCards = this.cards;
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    },
    handleInputFocus() {
      this.placeholderText = ''; // Al hacer clic en el input, establece el placeholder en una cadena vacía
    },
    handleInputBlur() {
      if (!this.searchQuery.trim()) {
          this.placeholderText = 'Busca pantalón, camiseta, sudadera...';
      }
  },
    increaseQuantity(card) {
      card.quantity++;
    },
    decreaseQuantity(card) {
      if (card.quantity > 1) {
        card.quantity--;
      }
    },
    handleMouseDown(event) {
      this.isDragging = true;
      this.startX = event.pageX - this.$refs.cardRow.offsetLeft;
      this.scrollLeft = this.$refs.cardRow.scrollLeft;
    },
    handleMouseUp() {
      this.isDragging = false;
    },
    handleMouseMove(event) {
      if (!this.isDragging) return;
      const x = event.pageX - this.$refs.cardRow.offsetLeft;
      const walk = (x - this.startX) * 3;
      this.$refs.cardRow.scrollLeft = this.scrollLeft - walk;
    },
    toggleView() {
      this.isGridView = !this.isGridView;
    },
    setGridView() {
      this.isGridView = true;
    },
    setRowView() {
      this.isGridView = false;
    },
    // Nuevo método para filtrar por categoría
    filterByCategory(category) {
      if (category === this.selectedCategory) {
        // If the same category is selected again, reset the filter
        this.selectedCategory = 'Todos';
        this.filteredCards = this.cards;
      } else {
        // Update selected category and apply the filter
        this.selectedCategory = category;
        this.filteredCards = (category === 'Todos') 
          ? this.cards 
          : this.cards.filter(card => card.category_id === category);
      }
    },
    toggleFavorite(index) {
      const adjustedIndex = index - 0;

      // Toggle the filled class on button click
      const button = document.querySelectorAll('.favorite')[adjustedIndex];
      button.classList.toggle('filled');

    },
 




    addToCart(index, quantity) {
      const existingCartItemIndex = this.cart.findIndex(item => item.index === index);
  
      if (existingCartItemIndex !== -1) {
        // Si el producto ya está en el carrito, actualiza la cantidad
        this.cart[existingCartItemIndex].quantity += quantity;
      } else {
        // Si el producto no está en el carrito, agrégalo
        this.cart.push({ index, quantity });
      }
  
      // Mostrar el indicador de actualización
      this.isUpdateIndicatorVisible = true;
    },
    removeFromCart(index) {
      this.cart.splice(index, 1);
    },
  
    toggleCart() {
      this.isCartOpen = !this.isCartOpen;
    },
  
    countTotalItemsInCart() {
      return this.cart.reduce((totalItems, item) => totalItems + item.quantity, 0);
    },
    

    

  },
});